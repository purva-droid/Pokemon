import random

class Ai(object):
    def __init__(self, num):
        self.num = num

#   returns a decision based on the battle state
    def decide(self, battle):
#       to begin we will return no decision and allow the game to auto-select a choice.
#       this is simulating running out of time to make our decision
        return None
        
        
