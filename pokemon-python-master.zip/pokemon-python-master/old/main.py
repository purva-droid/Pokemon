from sim.battle import Battle

battle = Battle(doubles=True)
battle.run()
