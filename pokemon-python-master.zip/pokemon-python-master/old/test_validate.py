from data import dex
from tools.validator import validate_team

validate_team(dex.sample_teams['team0'])
